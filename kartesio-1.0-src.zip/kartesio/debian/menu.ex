?package(kartesio):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="kartesio" command="/usr/bin/kartesio"
